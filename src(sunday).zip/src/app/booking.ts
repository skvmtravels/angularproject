export class Booking {
    booking_id:number;
    flight_no:number;
    user_id:number;
    bookDate:Date;
    noOfPassengers:number;
}
