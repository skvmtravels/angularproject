export class Contactus {
    firstName:String;
    lastName:String;
    email:String;
    phone:String;
    msg:String;
}
