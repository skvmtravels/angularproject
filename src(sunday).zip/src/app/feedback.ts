export class Feedback {
    name:String;
    email:String;
    msg:String;
    subscription:string;
    reference:string;
}
