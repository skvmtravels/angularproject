export class Newpassword {
    email:string;
    password:string;
}
