export class Otp {
    email:string;
    otp:number;
}
