export class Passenger {
    passenger_id:number;
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    adultOrChild:string;
}
