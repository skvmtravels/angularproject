import { Refundmail } from './refundmail';

describe('Refundmail', () => {
  it('should create an instance', () => {
    expect(new Refundmail()).toBeTruthy();
  });
});
