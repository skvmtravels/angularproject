export class Refundmail {
    booking_id:number;
    email:string;
}
