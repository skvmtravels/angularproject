import { Seatmap } from './seatmap';

describe('Seatmap', () => {
  it('should create an instance', () => {
    expect(new Seatmap()).toBeTruthy();
  });
});
