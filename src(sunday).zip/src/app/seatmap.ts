export class Seatmap {
    seatNo:string;
    travelDate:string;
}
