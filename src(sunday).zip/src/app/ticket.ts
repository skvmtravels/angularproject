export class Ticket {
    travelDate:string;
    seatNo:string;
    bookingStatus:boolean;
    flight_no:number;
    booking_id:number;
    passenger_id:number;
}
