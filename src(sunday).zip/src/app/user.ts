export class User {
    user_id:number;
	title:String;
	firstName:String;
	lastName:String;
	password:String;
	dob:Date;
	email:String;
	phoneNo:String;
	wallet:number;
	confirmpassword:string;
}
