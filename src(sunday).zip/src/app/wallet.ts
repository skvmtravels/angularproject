export class Wallet {
    wname:String;
    number:number;
    expmonth:String;
    pin:number;
    amt:number;
}