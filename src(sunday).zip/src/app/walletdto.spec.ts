import { Walletdto } from './walletdto';

describe('Walletdto', () => {
  it('should create an instance', () => {
    expect(new Walletdto()).toBeTruthy();
  });
});
