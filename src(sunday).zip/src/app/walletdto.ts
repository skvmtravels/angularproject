export class Walletdto {
    user_id:number;
    wallet:number;
}
